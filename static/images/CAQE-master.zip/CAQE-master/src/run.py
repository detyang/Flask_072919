#!/usr/bin/env python
# -*- coding: utf-8 -*-
from caqe import app

app.run(debug=True, threaded=True)