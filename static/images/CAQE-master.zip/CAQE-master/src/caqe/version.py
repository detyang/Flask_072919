#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Version info
"""

from __init__ import __version__

version = __version__
short_version = '.'.join(version.split('.')[:-1])