caqe.turk_admin module
======================

.. automodule:: caqe.turk_admin
    :members:
    :undoc-members:
    :show-inheritance:
